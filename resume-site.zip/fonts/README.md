# Vazirmatn font

For a fully offline version, place `Vazirmatn[wght].woff2` in this folder and add it to the `@font-face` source list in `css/styles.css`.

The current stylesheet uses `local("Vazirmatn")` first and then the Vazirmatn webfont CDN as a fallback.
