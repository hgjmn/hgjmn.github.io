/* Local diagnostics are opt-in and never send browser state to a server. */
(function () {
  "use strict";
  if (new URLSearchParams(location.search).get("debug") !== "locale") return;

  function init() {
    const root = document.documentElement;
    const panel = document.createElement("aside");
    panel.className = "locale-diagnostics notranslate";
    panel.lang = "fa";
    panel.dir = "rtl";
    panel.setAttribute("translate", "no");
    panel.setAttribute("aria-label", "وضعیت انتخاب زبان");
    const title = document.createElement("strong");
    title.textContent = "وضعیت انتخاب زبان";
    const details = document.createElement("pre");
    details.dir = "ltr";
    details.lang = "en";
    const close = document.createElement("button");
    close.type = "button";
    close.textContent = "بستن";
    close.addEventListener("click", () => {
      observer.disconnect();
      nameObserver.disconnect();
      panel.remove();
      const url = new URL(location.href);
      url.searchParams.delete("debug");
      history.replaceState({}, "", url);
    });
    panel.append(title, details, close);
    document.body.append(panel);

    function update() {
      let expectedName = "";
      try {
        const data = JSON.parse(document.getElementById("resume-data").textContent);
        expectedName = data[root.dataset.language]?.person.name || "";
      } catch (error) {}
      const renderedName = document.getElementById("hero-title")?.textContent.trim() || "";
      details.textContent = [
        "Version: 20261006e",
        `App: ${root.dataset.language || "pending"} | HTML: ${root.lang}`,
        `Source: ${root.dataset.localeSource || "pending"} | Status: ${root.dataset.geoStatus || "skipped"}`,
        `Country: ${root.dataset.country || "unknown"} | Provider: ${root.dataset.geoProvider || "none"}`,
        `Content matches app: ${expectedName && renderedName === expectedName ? "yes" : "no"}`
      ].join("\n");
    }
    const observer = new MutationObserver(update);
    observer.observe(root, { attributes: true, attributeFilter: [
      "lang", "data-language", "data-locale-source", "data-geo-status", "data-country", "data-geo-provider"
    ] });
    const nameObserver = new MutationObserver(update);
    const heading = document.getElementById("hero-title");
    if (heading) nameObserver.observe(heading, { childList: true, characterData: true, subtree: true });
    update();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
  else init();
}());
