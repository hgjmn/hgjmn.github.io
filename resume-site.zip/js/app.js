(() => {
  "use strict";

  const root = document.documentElement;
  const storage = {
    get(key) { try { return localStorage.getItem(key); } catch (error) { return null; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch (error) {} },
    remove(key) { try { localStorage.removeItem(key); } catch (error) {} }
  };
  const supportedLanguages = ["fa", "en", "zh", "ko", "tr"];
  const locale = window.ResumeLocale;
  const localeCopy = {
    fa: { auto: "خودکار", pending: "در حال تشخیص کشور IP", country: "کشور IP: {country}", fallback: "کشور IP قابل تشخیص نبود؛ فارسیِ پیش‌فرض نمایش داده می‌شود", privacy: "در حالت خودکار به GeoJS یا country.is متصل می‌شویم. این سایت IP را ذخیره نمی‌کند. VPN می‌تواند کشور را تغییر دهد." },
    en: { auto: "Auto", pending: "Checking IP country", country: "IP country: {country}", fallback: "IP country unavailable; using the default Persian language", privacy: "Automatic mode connects to GeoJS or country.is. This site does not store IP addresses. A VPN can change the detected country." },
    zh: { auto: "自动", pending: "正在检测 IP 所属国家", country: "IP 所属国家：{country}", fallback: "无法检测 IP 国家，已使用默认波斯语", privacy: "自动模式连接 GeoJS 或 country.is。本站不存储 IP 地址。VPN 可能改变检测到的国家。" },
    ko: { auto: "자동", pending: "IP 국가 확인 중", country: "IP 국가: {country}", fallback: "IP 국가를 확인할 수 없어 기본 언어인 페르시아어를 사용합니다", privacy: "자동 모드는 GeoJS 또는 country.is에 연결합니다. 이 사이트는 IP 주소를 저장하지 않습니다. VPN은 감지된 국가를 변경할 수 있습니다." },
    tr: { auto: "Otomatik", pending: "IP ülkesi kontrol ediliyor", country: "IP ülkesi: {country}", fallback: "IP ülkesi belirlenemedi; varsayılan Farsça kullanılıyor", privacy: "Otomatik mod GeoJS veya country.is hizmetine bağlanır. Bu site IP adreslerini saklamaz. VPN algılanan ülkeyi değiştirebilir." }
  };
  const interfaceCopy = {
    fa: { language: "انتخاب زبان", theme: "تغییر حالت رنگی", print: "چاپ یا دریافت PDF", menuOpen: "نمایش منو", menuClose: "بستن منو", home: "صفحه نخست", nav: "ناوبری اصلی", summary: "خلاصه حرفه‌ای", qr: "کد QR برای ارتباط سریع" },
    en: { language: "Select language", theme: "Toggle color theme", print: "Print or save PDF", menuOpen: "Open menu", menuClose: "Close menu", home: "Home", nav: "Main navigation", summary: "Professional summary", qr: "QR code for quick contact" },
    zh: { language: "选择语言", theme: "切换颜色主题", print: "打印或保存 PDF", menuOpen: "打开菜单", menuClose: "关闭菜单", home: "首页", nav: "主导航", summary: "职业概览", qr: "快速联系二维码" },
    ko: { language: "언어 선택", theme: "색상 테마 전환", print: "인쇄 또는 PDF 저장", menuOpen: "메뉴 열기", menuClose: "메뉴 닫기", home: "홈", nav: "주요 탐색", summary: "전문 요약", qr: "빠른 연락을 위한 QR 코드" },
    tr: { language: "Dil seçin", theme: "Renk temasını değiştir", print: "Yazdır veya PDF kaydet", menuOpen: "Menüyü aç", menuClose: "Menüyü kapat", home: "Ana sayfa", nav: "Ana gezinme", summary: "Profesyonel özet", qr: "Hızlı iletişim için QR kodu" }
  };
  const icons = {
    ledger: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v14H4zM8 9h8M8 13h3M8 17h8"/></svg>',
    tax: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 3h14v18H5zM8 7h8M8 11h8M8 15h3M15 15h1"/></svg>',
    chart: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20V4M4 20h16M8 16v-4M12 16V7M16 16v-8"/></svg>',
    spark: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3ZM19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/></svg>',
    target: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 2v2M22 12h-2M12 22v-2M2 12h2"/></svg>',
    user: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.7-4 4.4-6 8-6s6.3 2 8 6"/></svg>',
    phone: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 3.5 4 6c1 6 7 12 13 14l2.5-2.5-3.2-3.2-2 1c-1.7-.8-3.5-2.6-4.3-4.3l1-2-3.2-3.2Z"/></svg>',
    telegram: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 4-3.2 16-5.8-5.1-3.2 2.8.7-4.4 8.2-7.6-10.2 6.1L3 10.3 21 4Z"/></svg>',
    bale: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4h12v11H9l-3 3V4Z"/><path d="M9 8h6M9 11h4"/></svg>'
  };

  let resume = null;
  let language = supportedLanguages.includes(root.dataset.language) ? root.dataset.language : "fa";
  let theme = root.dataset.theme === "light" ? "light" : "dark";
  let typingTimer = 0;
  let revealObserver = null;
  let manualLanguage = supportedLanguages.includes(storage.get("resume.lang.manual")) ? storage.get("resume.lang.manual") : "";
  let localeRequest = 0;
  let localeController = null;

  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[character]);
  const valueAt = (source, path) => path.split(".").reduce((current, key) => current?.[key], source);
  const current = () => resume?.[language] || resume?.en || resume?.fa;

  function getEmbeddedData() {
    try { return JSON.parse(document.getElementById("resume-data")?.textContent || "{}"); } catch (error) { return {}; }
  }

  async function loadResume() {
    const embedded = getEmbeddedData();
    try {
      const response = await fetch("resume.json", { cache: "no-store" });
      if (!response.ok) throw new Error("resume.json unavailable");
      return await response.json();
    } catch (error) {
      return embedded.fa && embedded.en ? embedded : null;
    }
  }

  function setLanguage(nextLanguage, options = {}) {
    language = supportedLanguages.includes(nextLanguage) && resume?.[nextLanguage] ? nextLanguage : (resume?.en ? "en" : "fa");
    root.lang = language;
    root.dir = language === "fa" ? "rtl" : "ltr";
    root.dataset.language = language;
    root.dataset.localeSource = options.source || root.dataset.localeSource || "runtime";
    if (options.persist) {
      manualLanguage = language;
      storage.set("resume.lang.manual", language);
      storage.remove("resume.lang");
      root.dataset.localeSource = "manual";
    }
  }

  function setTheme(nextTheme) {
    theme = nextTheme;
    root.dataset.theme = theme;
    storage.set("resume.theme", theme);
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", theme === "dark" ? "#111312" : "#f3f5f0");
  }

  function renderBoundText(data) {
    document.querySelectorAll("[data-bind]").forEach((element) => {
      const value = valueAt(data, element.dataset.bind);
      if (value) element.textContent = value;
    });
    document.querySelectorAll("[data-i18n]").forEach((element) => {
      const value = valueAt(data, element.dataset.i18n);
      if (value) element.textContent = value;
    });
    const labels = interfaceCopy[language] || interfaceCopy.en;
    const languageSelect = document.querySelector("[data-language-select]");
    if (languageSelect) {
      const source = root.dataset.localeSource;
      languageSelect.value = ["country", "default", "pending"].includes(source) ? "auto" : language;
      const copy = localeCopy[language] || localeCopy.en;
      const auto = languageSelect.querySelector('[value="auto"]');
      if (auto) auto.textContent = copy.auto;
      let region = root.dataset.country || "";
      try { if (region && Intl.DisplayNames) region = new Intl.DisplayNames([language], { type: "region" }).of(region); } catch (error) {}
      const status = source === "pending" ? copy.pending : (source === "country" ? copy.country.replace("{country}", region) : copy.fallback);
      languageSelect.title = source === "manual" || source === "url" ? labels.language : `${status}. ${copy.privacy}`;
      languageSelect.setAttribute("aria-label", labels.language);
    }
    document.querySelector(".language-control")?.setAttribute("aria-label", labels.language);
    document.querySelector("[data-theme-toggle]")?.setAttribute("aria-label", labels.theme);
    document.querySelector("[data-print]")?.setAttribute("aria-label", labels.print);
    document.querySelector("[data-menu-toggle]")?.setAttribute("aria-label", labels.menuOpen);
    document.querySelector(".brand")?.setAttribute("aria-label", labels.home);
    document.querySelector(".site-header nav")?.setAttribute("aria-label", labels.nav);
    document.querySelector(".identity-panel")?.setAttribute("aria-label", labels.summary);
    document.querySelector(".qr-card img")?.setAttribute("alt", labels.qr || data.labels.scan);
    document.title = data.meta.title;
    document.querySelector('meta[name="description"]')?.setAttribute("content", data.meta.description);
    document.querySelector('meta[property="og:title"]')?.setAttribute("content", data.meta.title);
    document.querySelector('meta[property="og:description"]')?.setAttribute("content", data.meta.description);
    document.querySelector('meta[name="twitter:title"]')?.setAttribute("content", data.meta.title);
    document.querySelector('meta[name="twitter:description"]')?.setAttribute("content", data.meta.description);
  }

  function renderQuickFacts(items) {
    const target = document.querySelector("[data-quick-facts]");
    if (!target) return;
    target.innerHTML = items.map((item) => `<div><dt>${escapeHtml(item.label)}</dt><dd>${escapeHtml(item.value)}</dd></div>`).join("");
  }

  function renderMetrics(items) {
    const target = document.querySelector("[data-metrics]");
    if (!target) return;
    target.innerHTML = items.map((item) => `<div><strong><bdi dir="auto">${escapeHtml(item.value)}</bdi></strong><span>${escapeHtml(item.label)}</span></div>`).join("");
  }

  function renderExperience(items) {
    const target = document.querySelector("[data-experience]");
    if (!target) return;
    target.innerHTML = items.map((item) => `<article class="timeline-item reveal"><div class="timeline-card"><span class="timeline-meta">${escapeHtml(item.period)}</span><h3>${escapeHtml(item.role)}</h3><p>${escapeHtml(item.summary)}</p><ul class="clean-list">${item.items.map((point) => `<li>${escapeHtml(point)}</li>`).join("")}</ul></div></article>`).join("");
  }

  function renderSkills(items) {
    const target = document.querySelector("[data-skills]");
    if (!target) return;
    target.innerHTML = items.map((item, index) => `<article class="skill-card reveal"><div class="skill-heading"><span class="skill-icon">${icons[item.icon] || icons.target}</span><span class="skill-index" aria-hidden="true">${new Intl.NumberFormat(language, { minimumIntegerDigits: 2 }).format(index + 1)}</span></div><h3>${escapeHtml(item.title)}</h3><ul class="pill-list">${item.items.map((skill) => `<li><bdi dir="auto">${escapeHtml(skill)}</bdi></li>`).join("")}</ul></article>`).join("");
  }

  function renderProjects(items) {
    const target = document.querySelector("[data-projects]");
    if (!target) return;
    target.innerHTML = items.map((item, index) => `<article class="project-card project-card--${(index % 3) + 1} reveal"><div class="project-preview"><img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" loading="lazy" decoding="async"></div><div class="project-body"><span class="project-type">${escapeHtml(item.type)}</span><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p><div class="project-tech">${item.tech.map((tech) => `<span>${escapeHtml(tech)}</span>`).join("")}</div><ul class="clean-list">${item.achievements.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul></div></article>`).join("");
  }

  function renderDetails(data) {
    const education = document.querySelector("[data-education]");
    const courses = document.querySelector("[data-courses]");
    const languages = document.querySelector("[data-languages]");
    if (education) education.innerHTML = `<strong>${escapeHtml(data.education.title)}</strong><p>${escapeHtml(data.education.place)}</p>`;
    if (courses) courses.innerHTML = data.courses.map((course) => `<li>${escapeHtml(course)}</li>`).join("");
    if (languages) languages.innerHTML = data.languages.map((item) => `<p><strong>${escapeHtml(item.name)}:</strong> ${escapeHtml(item.level)}</p>`).join("");
  }

  function renderContacts(items) {
    const target = document.querySelector("[data-contact-links]");
    if (!target) return;
    target.innerHTML = items.map((item) => `<a class="contact-link" href="${escapeHtml(item.href)}" target="${item.href.startsWith("http") ? "_blank" : "_self"}" rel="noopener"><span class="contact-icon">${icons[item.icon] || icons.phone}</span><span><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(item.value)}</small></span></a>`).join("");
  }

  function getPrintTimestamp() {
    const now = new Date();
    const dateLocales = { fa: "fa-IR-u-ca-persian", en: "en-US-u-ca-persian", zh: "zh-CN-u-ca-persian", ko: "ko-KR-u-ca-persian", tr: "tr-TR-u-ca-persian" };
    const timeLocales = { fa: "fa-IR", en: "en-GB", zh: "zh-CN", ko: "ko-KR", tr: "tr-TR" };
    const dateLocale = dateLocales[language] || dateLocales.en;
    const timeLocale = timeLocales[language] || timeLocales.en;
    const date = new Intl.DateTimeFormat(dateLocale, { timeZone: "Asia/Tehran", day: "numeric", month: "long", year: "numeric" }).format(now);
    const time = new Intl.DateTimeFormat(timeLocale, { timeZone: "Asia/Tehran", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(now);
    const templates = {
      fa: `به‌روزرسانی: ${date}، ساعت ${time} (تهران)`,
      en: `Updated (Persian calendar): ${date}, ${time} Tehran`,
      zh: `更新（波斯历）：${date}，德黑兰时间 ${time}`,
      ko: `업데이트(페르시아력): ${date}, 테헤란 ${time}`,
      tr: `Güncelleme (İran takvimi): ${date}, Tahran ${time}`
    };
    return templates[language] || templates.en;
  }

  function renderPrintResume(data) {
    const target = document.querySelector("[data-print-resume]");
    if (!target) return;
    const isPersian = language === "fa";
    const printLabels = {
      fa: {
        document: "رزومه حرفه‌ای | خلاصه یک‌صفحه‌ای",
        overview: "خلاصه حرفه‌ای",
        experience: "مسیر تجربه",
        focus: "نقشه تمرکز مهارتی",
        work: "نمونه‌کارهای منتخب",
        education: "تحصیلات و ابزارهای کاری",
        contact: "راه‌های ارتباطی"
      },
      en: {
        document: "Professional Resume | One-page Summary",
        overview: "Professional Overview",
        experience: "Experience Snapshot",
        focus: "Skills Focus Map",
        work: "Selected Work",
        education: "Education and Tools",
        contact: "Contact"
      },
      zh: {
        document: "专业简历 | 单页摘要",
        overview: "职业概览",
        experience: "经历概览",
        focus: "技能重点",
        work: "精选项目",
        education: "教育与工作工具",
        contact: "联系方式"
      },
      ko: {
        document: "전문 이력서 | 1페이지 요약",
        overview: "전문 요약",
        experience: "경력 요약",
        focus: "핵심 기술",
        work: "주요 프로젝트",
        education: "학력 및 업무 도구",
        contact: "연락처"
      },
      tr: {
        document: "Profesyonel Özgeçmiş | Tek Sayfalık Özet",
        overview: "Profesyonel Özet",
        experience: "Deneyim Özeti",
        focus: "Temel Yetkinlikler",
        work: "Seçili Projeler",
        education: "Eğitim ve Çalışma Araçları",
        contact: "İletişim"
      }
    };
    const labels = printLabels[language] || printLabels.en;
    const focusWidths = [100, 72, 68, 60];
    const experience = data.experience.map((item) => `<li><strong>${escapeHtml(item.role)}</strong><span>${escapeHtml(item.period)}</span></li>`).join("");
    const focus = data.metrics.map((item, index) => `<li><span><strong>${escapeHtml(item.value)}</strong><small>${escapeHtml(item.label)}</small></span><i><b style="--focus:${focusWidths[index] || 58}%"></b></i></li>`).join("");
    const projects = data.projects.map((item) => `<li><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.achievements?.[0] || item.description)}</span></li>`).join("");
    const contacts = data.contacts.map((item) => `<span>${escapeHtml(item.value)}</span>`).join("<i aria-hidden=\"true\"></i>");
    target.lang = language;
    target.dir = isPersian ? "rtl" : "ltr";
    target.innerHTML = `<article class="print-sheet"><header class="print-header"><div><p class="print-kicker">${labels.document}</p><h1>${escapeHtml(data.person.name)}</h1><p class="print-title">${escapeHtml(data.person.shortTitle)}</p><p class="print-contact-line">${escapeHtml(data.person.city)} <i aria-hidden="true"></i> ${escapeHtml(data.person.phone)}</p></div><p class="print-timestamp" data-print-timestamp>${escapeHtml(getPrintTimestamp())}</p></header><section class="print-overview"><h2>${labels.overview}</h2><p>${escapeHtml(data.person.summary)}</p></section><div class="print-grid"><section class="print-block print-experience"><h2>${labels.experience}</h2><ol>${experience}</ol></section><section class="print-block print-focus"><h2>${labels.focus}</h2><ul>${focus}</ul></section></div><section class="print-work"><h2>${labels.work}</h2><ul>${projects}</ul></section><footer class="print-footer"><section><h2>${labels.education}</h2><p><strong>${escapeHtml(data.education.title)}</strong> - ${escapeHtml(data.education.place)}</p><p>${data.courses.map(escapeHtml).join(" | ")}</p></section><section><h2>${labels.contact}</h2><p class="print-contact-list">${contacts}</p></section></footer></article>`;
  }

  function updatePrintTimestamp() {
    document.querySelectorAll("[data-print-timestamp]").forEach((element) => { element.textContent = getPrintTimestamp(); });
  }

  function renderSchema(data) {
    const schema = { "@context": "https://schema.org", "@type": "Person", name: "Amirhossein Heshmat", alternateName: "امیرحسین حشمت", jobTitle: data.person.shortTitle, address: { "@type": "PostalAddress", addressLocality: data.person.city, addressCountry: "IR" }, telephone: "+989014487699", sameAs: data.contacts.filter((item) => item.href.startsWith("http")).map((item) => item.href) };
    document.getElementById("person-schema").textContent = JSON.stringify(schema);
  }

  function startTyping(words) {
    window.clearTimeout(typingTimer);
    const target = document.querySelector("[data-typing]");
    if (!target || !words?.length || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      if (target) { target.textContent = words?.[0] || ""; target.classList.remove("is-typing"); }
      return;
    }
    target.classList.add("is-typing");
    let word = 0;
    let letter = words[0].length;
    let deleting = true;
    target.textContent = words[0];
    const update = () => {
      const source = words[word];
      target.textContent = source.slice(0, letter);
      if (!deleting && letter < source.length) { letter += 1; typingTimer = window.setTimeout(update, 54); return; }
      if (!deleting) { deleting = true; typingTimer = window.setTimeout(update, 1450); return; }
      if (letter > 0) { letter -= 1; typingTimer = window.setTimeout(update, 28); return; }
      deleting = false;
      word = (word + 1) % words.length;
      typingTimer = window.setTimeout(update, 320);
    };
    typingTimer = window.setTimeout(update, 1800);
  }

  function setupReveal() {
    revealObserver?.disconnect();
    const nodes = document.querySelectorAll(".reveal");
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) { nodes.forEach((node) => node.classList.add("is-visible")); return; }
    revealObserver = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) { entry.target.classList.add("is-visible"); revealObserver.unobserve(entry.target); } }), { threshold: .12 });
    nodes.forEach((node) => revealObserver.observe(node));
  }

  function setupNavigation() {
    const button = document.querySelector("[data-menu-toggle]");
    const links = document.querySelector("[data-nav-links]");
    const setMenuState = (open) => {
      links?.classList.toggle("is-open", open);
      button?.setAttribute("aria-expanded", String(open));
      const labels = interfaceCopy[language] || interfaceCopy.en;
      button?.setAttribute("aria-label", open ? labels.menuClose : labels.menuOpen);
    };
    button?.addEventListener("click", () => setMenuState(!links?.classList.contains("is-open")));
    links?.addEventListener("click", (event) => { if (event.target.closest("a")) setMenuState(false); });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && links?.classList.contains("is-open")) {
        setMenuState(false);
        button?.focus();
      }
    });
    const navLinks = [...document.querySelectorAll("[data-nav-links] a")];
    const sections = navLinks.map((link) => document.querySelector(link.hash)).filter(Boolean);
    if ("IntersectionObserver" in window) {
      const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) navLinks.forEach((link) => link.classList.toggle("is-active", link.hash === `#${entry.target.id}`)); }), { rootMargin: "-42% 0px -52%", threshold: .01 });
      sections.forEach((section) => observer.observe(section));
    }
  }

  function setupPointerGlow() {
    if (!window.matchMedia("(pointer: fine)").matches || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    document.body.classList.add("has-pointer");
    let pointerFrame = 0;
    let pointerX = 0;
    let pointerY = 0;
    window.addEventListener("pointermove", (event) => {
      pointerX = event.clientX;
      pointerY = event.clientY;
      if (pointerFrame) return;
      pointerFrame = window.requestAnimationFrame(() => {
        root.style.setProperty("--pointer-x", `${pointerX}px`);
        root.style.setProperty("--pointer-y", `${pointerY}px`);
        pointerFrame = 0;
      });
    }, { passive: true });
  }

  function setupScrollProgress() {
    const bar = document.querySelector("[data-scroll-progress]");
    if (!bar) return;
    let ticking = false;
    const update = () => {
      const doc = document.documentElement;
      const scrollTop = window.scrollY || doc.scrollTop || 0;
      const height = doc.scrollHeight - doc.clientHeight;
      const ratio = height > 0 ? Math.min(1, Math.max(0, scrollTop / height)) : 0;
      root.style.setProperty("--scroll-progress", `${(ratio * 100).toFixed(2)}%`);
      bar.classList.toggle("is-scrolled", scrollTop > 4);
      ticking = false;
    };
    const onScroll = () => { if (!ticking) { window.requestAnimationFrame(update); ticking = true; } };
    window.addEventListener("scroll", onScroll, { passive: true });
    update();
  }

  function setupTiltCards() {
    if (!window.matchMedia("(pointer: fine)").matches || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const cards = document.querySelectorAll(".project-preview");
    // Maximum tilt angle in degrees; kept subtle to stay professional.
    const MAX_TILT = 1.4;
    const EASE = 0.14; // interpolation factor per frame for smooth trailing motion
    cards.forEach((card) => {
      if (card.dataset.tiltReady === "true") return;
      card.dataset.tiltReady = "true";
      let targetX = 0, targetY = 0, currentX = 0, currentY = 0, raf = 0;
      const reset = () => {
        targetX = 0; targetY = 0;
        if (!raf) raf = requestAnimationFrame(loop);
        card.style.removeProperty("--spot-x");
        card.style.removeProperty("--spot-y");
      };
      const onMove = (event) => {
        card.classList.add("is-tilting");
        const rect = card.getBoundingClientRect();
        const px = (event.clientX - rect.left) / rect.width; // 0..1
        const py = (event.clientY - rect.top) / rect.height; // 0..1
        // Rotate toward the cursor: positive pointer on the right -> negative rotateY (right edge dips back).
        targetX = -(py - 0.5) * 2 * MAX_TILT;
        targetY = (px - 0.5) * 2 * MAX_TILT;
        card.style.setProperty("--spot-x", `${px * 100}%`);
        card.style.setProperty("--spot-y", `${py * 100}%`);
        if (!raf) raf = requestAnimationFrame(loop);
      };
      const loop = () => {
        currentX += (targetX - currentX) * EASE;
        currentY += (targetY - currentY) * EASE;
        card.style.setProperty("--tilt-x", `${currentX.toFixed(2)}deg`);
        card.style.setProperty("--tilt-y", `${currentY.toFixed(2)}deg`);
        const settled = Math.abs(targetX - currentX) < 0.02 && Math.abs(targetY - currentY) < 0.02;
        if (settled) {
          currentX = targetX;
          currentY = targetY;
          card.style.setProperty("--tilt-x", `${currentX.toFixed(2)}deg`);
          card.style.setProperty("--tilt-y", `${currentY.toFixed(2)}deg`);
          if (targetX === 0 && targetY === 0) card.classList.remove("is-tilting");
          raf = 0;
          return;
        }
        raf = requestAnimationFrame(loop);
      };
      card.addEventListener("pointerenter", () => card.classList.add("is-tilting"));
      card.addEventListener("pointermove", onMove, { passive: true });
      card.addEventListener("pointerleave", reset);
    });
  }

  function runLoader() {
    const loader = document.querySelector("[data-loader]");
    if (!loader) return;
    const video = loader.querySelector("[data-loader-video]");
    const percentEl = loader.querySelector("[data-loader-percent]");
    const statusEl = loader.querySelector("[data-loader-status]");
    const storyEl = loader.querySelector("[data-loader-story]");
    const frameEl = loader.querySelector(".loader-video-container");
    const stepEls = [...loader.querySelectorAll("[data-loader-step]")];
    const copy = {
      fa: { story: "حسابداری، داده و اتوماسیون در یک نشان", identity: "در حال ترسیم هویت مالی", data: "در حال اتصال تحلیل و داده", automation: "در حال تکمیل اتوماسیون دیجیتال", ready: "هویت حرفه‌ای آماده است", steps: ["هویت مالی", "تحلیل داده", "اتوماسیون"] },
      en: { story: "Accounting, data and automation in one mark", identity: "Shaping the financial identity", data: "Connecting analysis and data", automation: "Completing digital automation", ready: "Professional identity is ready", steps: ["Financial identity", "Data analysis", "Automation"] },
      zh: { story: "会计、数据与自动化融为一个标志", identity: "正在勾勒财务身份", data: "正在连接分析与数据", automation: "正在完成数字自动化", ready: "职业形象已准备就绪", steps: ["财务身份", "数据分析", "自动化"] },
      ko: { story: "회계, 데이터, 자동화를 하나의 상징으로", identity: "재무 정체성을 그리는 중", data: "분석과 데이터를 연결하는 중", automation: "디지털 자동화를 완성하는 중", ready: "전문 브랜드가 준비되었습니다", steps: ["재무 정체성", "데이터 분석", "자동화"] },
      tr: { story: "Muhasebe, veri ve otomasyon tek bir simgede", identity: "Finansal kimlik oluşturuluyor", data: "Analiz ve veriler bağlanıyor", automation: "Dijital otomasyon tamamlanıyor", ready: "Profesyonel kimlik hazır", steps: ["Finansal kimlik", "Veri analizi", "Otomasyon"] }
    }[language] || null;
    const loaderCopy = copy || {
      story: "Accounting, data and automation in one mark",
      identity: "Shaping the financial identity",
      data: "Connecting analysis and data",
      automation: "Completing digital automation",
      ready: "Professional identity is ready",
      steps: ["Financial identity", "Data analysis", "Automation"]
    };
    if (storyEl) storyEl.textContent = loaderCopy.story;
    loader.setAttribute("aria-label", loaderCopy.story);
    stepEls.forEach((element, index) => {
      const label = element.querySelector("span");
      if (label) label.textContent = loaderCopy.steps[index] || "";
    });

    const localizeNumber = (value) => language === "fa"
      ? String(value).replace(/\d/g, (digit) => "۰۱۲۳۴۵۶۷۸۹"[Number(digit)])
      : String(value);
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const started = performance.now();
    let durationMs = 8000;
    let playbackStarted = false;
    let loaderFinished = false;
    let safetyTimer = 0;

    const finish = () => {
      if (loaderFinished) return;
      loaderFinished = true;
      window.clearTimeout(safetyTimer);
      loader.dataset.phase = "ready";
      loader.style.setProperty("--loader-progress", "1");
      loader.style.setProperty("--loader-scan-x", `${frameEl?.clientWidth || 0}px`);
      if (percentEl) percentEl.textContent = language === "fa" ? "۱۰۰٪" : "100%";
      if (statusEl) statusEl.textContent = loaderCopy.ready;
      window.setTimeout(() => {
        root.dataset.appState = "ready";
        loader.classList.add("is-leaving");
        window.setTimeout(() => loader.remove(), 620);
      }, reducedMotion ? 700 : 2000);
    };

    const tick = () => {
      if (loaderFinished) return;
      const elapsed = performance.now() - started;
      const mediaProgress = video && playbackStarted && Number.isFinite(video.duration) && video.duration > 0
        ? video.currentTime / video.duration
        : elapsed / durationMs;
      const progress = Math.max(0, Math.min(1, mediaProgress));
      const pct = Math.floor(progress * 100);
      const phase = progress < .34 ? "identity" : progress < .68 ? "data" : progress < .995 ? "automation" : "ready";
      loader.dataset.phase = phase;
      loader.style.setProperty("--loader-progress", progress.toFixed(4));
      loader.style.setProperty("--loader-scan-x", `${(frameEl?.clientWidth || 0) * progress}px`);
      if (percentEl) percentEl.textContent = `${localizeNumber(pct)}${language === "fa" ? "٪" : "%"}`;
      if (statusEl) statusEl.textContent = loaderCopy[phase];
      if (progress >= .999) finish(); else requestAnimationFrame(tick);
    };

    if (video) {
      video.muted = true;
      video.volume = 0;
      const onMetadata = () => {
        if (Number.isFinite(video.duration) && video.duration > 0) durationMs = video.duration * 1000;
        if (reducedMotion) {
          try { video.currentTime = Math.max(0, video.duration - .08); } catch (error) {}
          window.setTimeout(finish, 900);
        }
      };
      if (video.readyState >= 1) onMetadata();
      else video.addEventListener("loadedmetadata", onMetadata, { once: true });
      video.addEventListener("playing", () => { playbackStarted = true; }, { once: true });
      video.addEventListener("ended", finish, { once: true });
      video.addEventListener("error", () => { playbackStarted = false; }, { once: true });
      if (!reducedMotion) video.play().catch(() => { playbackStarted = false; });
    }
    safetyTimer = window.setTimeout(finish, 11000);
    requestAnimationFrame(tick);
  }

  function render() {
    const data = current();
    if (!data) return;
    renderBoundText(data);
    renderQuickFacts(data.quickFacts);
    renderMetrics(data.metrics);
    renderExperience(data.experience);
    renderSkills(data.skills);
    renderProjects(data.projects);
    renderDetails(data);
    renderContacts(data.contacts);
    renderPrintResume(data);
    renderSchema(data);
    startTyping(data.typing);
    setupReveal();
    setupTiltCards();
  }

  async function autoDetectGeoLanguage(options = {}) {
    const requested = new URLSearchParams(window.location.search).get("lang");
    if (manualLanguage || (!options.force && supportedLanguages.includes(requested))) return;
    localeController?.abort();
    localeController = new AbortController();
    const requestId = ++localeRequest;
    root.dataset.geoStatus = "pending";
    root.dataset.localeSource = "pending";
    renderBoundText(current());
    const result = await locale.detectCountry({ signal: localeController.signal });
    // Late responses never overwrite manual choices or a newer automatic request.
    if (requestId !== localeRequest || manualLanguage || result.status === "cancelled") return;
    const { country } = result;
    root.dataset.geoStatus = result.status;
    root.dataset.geoProvider = result.provider;
    if (country) {
      root.dataset.country = country;
    } else {
      root.removeAttribute("data-country");
    }
    const automatic = locale.resolveAutomatic(country);
    setLanguage(automatic.language, { source: automatic.source });
    render();
  }

  document.addEventListener("DOMContentLoaded", async () => {
    resume = await loadResume();
    setLanguage(language, { source: root.dataset.localeSource || "initial" });
    setTheme(theme);
    render();
    setupNavigation();
    setupPointerGlow();
    setupScrollProgress();
    document.querySelector("[data-language-select]")?.addEventListener("change", async (event) => {
      if (!resume) return;
      document.querySelector("[data-nav-links]")?.classList.remove("is-open");
      document.querySelector("[data-menu-toggle]")?.setAttribute("aria-expanded", "false");
      if (event.target.value === "auto") {
        manualLanguage = "";
        storage.remove("resume.lang.manual");
        const url = new URL(window.location.href);
        url.searchParams.delete("lang");
        window.history.replaceState({}, "", url);
        await autoDetectGeoLanguage({ force: true });
        return;
      }
      ++localeRequest;
      localeController?.abort();
      setLanguage(event.target.value, { persist: true });
      const url = new URL(window.location.href);
      url.searchParams.delete("lang");
      window.history.replaceState({}, "", url);
      render();
    });
    document.querySelector("[data-theme-toggle]")?.addEventListener("click", () => setTheme(theme === "dark" ? "light" : "dark"));
    window.addEventListener("beforeprint", () => { if (current()) { renderPrintResume(current()); updatePrintTimestamp(); } });
    document.querySelector("[data-print]")?.addEventListener("click", () => { if (current()) { renderPrintResume(current()); updatePrintTimestamp(); } window.requestAnimationFrame(() => window.print()); });
    await autoDetectGeoLanguage();
    runLoader();
  });
})();
