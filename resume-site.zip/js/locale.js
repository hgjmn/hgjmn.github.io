/* Country lookup is separate from UI state so failures and priority are testable. */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.ResumeLocale = api;
}(globalThis, function () {
  "use strict";
  const providers = [
    { url: "https://api.country.is/", name: "country-is", external: true },
    { url: "https://get.geojs.io/v1/ip/country.json", name: "geojs", external: true }
  ];

  function normalizeCountry(value) {
    const code = String(value || "").trim().toUpperCase();
    return /^[A-Z]{2}$/.test(code) && !["XX", "T1", "ZZ"].includes(code) ? code : "";
  }

  function fromCountry(country) {
    const code = normalizeCountry(country);
    if (code === "IR") return "fa";
    if (["CN", "TW", "HK", "MO"].includes(code)) return "zh";
    if (["KR", "KP"].includes(code)) return "ko";
    if (code === "TR") return "tr";
    return "en";
  }

  function fromBrowser(locales) {
    for (const item of locales || []) {
      const code = String(item || "").toLowerCase().split(/[-_]/)[0];
      if (["fa", "en", "zh", "ko", "tr"].includes(code)) return code;
    }
    return "en";
  }

  function resolveAutomatic(country) {
    const code = normalizeCountry(country);
    // A browser preference is not evidence of the visitor's IP country.
    return { language: code ? fromCountry(code) : "fa", source: code ? "country" : "default" };
  }

  async function detectCountry({ signal, fetcher = fetch, timeoutMs = 2500 } = {}) {
    async function query(provider) {
      const empty = { country: "", provider: provider.name, status: "unavailable" };
      if (signal?.aborted) return empty;
      const controller = new AbortController();
      const cancel = () => controller.abort();
      signal?.addEventListener("abort", cancel, { once: true });
      const timer = setTimeout(cancel, provider.external ? timeoutMs : Math.min(timeoutMs, 1500));
      try {
        const url = provider.external ? `${provider.url}?_=${Date.now()}-${Math.random().toString(36).slice(2, 8)}` : provider.url;
        const response = await fetcher(url, {
          cache: "no-store", credentials: provider.external ? "omit" : "same-origin",
          headers: { Accept: "application/json" },
          referrerPolicy: provider.external ? "no-referrer" : "same-origin",
          signal: controller.signal
        });
        if (!response.ok || !response.headers.get("content-type")?.includes("application/json")) return empty;
        const data = await response.json();
        const country = normalizeCountry(data?.country_code || data?.country);
        if (country && !signal?.aborted) return { country, provider: provider.name, status: "resolved" };
      } catch (error) {
        // Keep country-only results; do not retain provider-returned IP addresses.
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener("abort", cancel);
      }
      return empty;
    }
    // Compare both approved sources in parallel instead of trusting the first answer.
    const checks = await Promise.all(providers.filter(provider => provider.external).map(query));
    if (signal?.aborted) return { country: "", provider: "", status: "cancelled", checks };
    const valid = checks.filter(check => check.country);
    if (new Set(valid.map(check => check.country)).size > 1) {
      return { country: "", provider: valid.map(check => check.provider).join("+"), status: "conflict", checks };
    }
    if (valid.length) {
      return { country: valid[0].country, provider: valid.map(check => check.provider).join("+"), status: "resolved", checks };
    }
    for (const provider of providers.filter(provider => !provider.external)) {
      const check = await query(provider);
      checks.push(check);
      if (signal?.aborted) return { country: "", provider: "", status: "cancelled", checks };
      if (check.country) return { ...check, checks };
    }
    return { country: "", provider: "", status: "unavailable", checks };
  }

  return Object.freeze({ normalizeCountry, fromCountry, fromBrowser, resolveAutomatic, detectCountry });
}));
